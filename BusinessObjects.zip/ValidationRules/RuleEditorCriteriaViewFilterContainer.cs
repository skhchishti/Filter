﻿using DevExpress.Persistent.Validation;


namespace Filter.Module.ValidationRules {
    [CodeRule]
    public class RuleEditorCriteriaViewFilterContainer : RuleEditorCriteriaBase {
        public RuleEditorCriteriaViewFilterContainer() : base(nameof(RuleEditorCriteriaViewFilterContainer), "Save", typeof(ViewFilterContainer)) { }
        public RuleEditorCriteriaViewFilterContainer(IRuleBaseProperties properties) : base(properties) { }
        protected override string TargetPropertyName => nameof(ViewFilterContainer.Criteria);
    }
}
