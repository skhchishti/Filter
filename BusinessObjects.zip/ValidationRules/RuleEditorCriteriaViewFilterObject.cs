﻿using DevExpress.Persistent.Validation;


namespace Filter.Module.ValidationRules {
    [CodeRule]
    public class RuleEditorCriteriaViewFilterObject : RuleEditorCriteriaBase {
        public RuleEditorCriteriaViewFilterObject() : base(nameof(RuleEditorCriteriaViewFilterObject), "Save", typeof(ViewFilterObject)) { }
        public RuleEditorCriteriaViewFilterObject(IRuleBaseProperties properties) : base(properties) { }
        protected override string TargetPropertyName => nameof(ViewFilterObject.Criteria);
    }
}
