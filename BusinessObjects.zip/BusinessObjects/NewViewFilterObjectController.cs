﻿using System;
using DevExpress.ExpressApp;
using DevExpress.ExpressApp.SystemModule;

namespace Filter.Module {
    public class NewViewFilterObjectController : ObjectViewController<ListView, ViewFilterObject> {
        public NewViewFilterObjectController() {
            TargetViewId = "ViewFilterObject_LookupListView";
        }
        protected override void OnActivated() {
            base.OnActivated();
            if (Frame is NestedFrame && ((NestedFrame)Frame).ViewItem.CurrentObject is ViewFilterContainer) {
                NewObjectViewController newObjectViewController = Frame.GetController<NewObjectViewController>();
                if (newObjectViewController != null) { 
                    newObjectViewController.ObjectCreated += new EventHandler<ObjectCreatedEventArgs>(ViewController1_ObjectCreated);
                }     
            }
        }
        void ViewController1_ObjectCreated(object sender, ObjectCreatedEventArgs e) {
            if (e.CreatedObject is ViewFilterObject newViewFilterObject) {
                newViewFilterObject.ObjectType = ((ViewFilterContainer)((NestedFrame)Frame).ViewItem.CurrentObject).ObjectType;
            }
        }
        protected override void OnDeactivated() {
            base.OnDeactivated();
            if (View.CollectionSource is PropertyCollectionSource && ((PropertyCollectionSource)View.CollectionSource).MasterObjectType == typeof(ViewFilterContainer)) {
                NewObjectViewController newObjectViewController = Frame.GetController<NewObjectViewController>();
                if (newObjectViewController != null) { 
                    newObjectViewController.ObjectCreated -= new EventHandler<ObjectCreatedEventArgs>(ViewController1_ObjectCreated);
                }
            }
        }
    }
}
