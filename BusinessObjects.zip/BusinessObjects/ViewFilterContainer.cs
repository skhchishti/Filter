using System;
using DevExpress.ExpressApp.Editors;
using System.ComponentModel;
using DevExpress.Persistent.Base;
using DevExpress.ExpressApp;
using DevExpress.Data.Filtering;
using DevExpress.ExpressApp.DC;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using DevExpress.Persistent.Validation;

namespace Filter.Module {
    [DomainComponent]
    public class ViewFilterContainer : INotifyPropertyChanged {
        private ViewFilterObject _Filter;
        [DataSourceCriteria("ObjectType = '@This.ObjectType'")]
        [ImmediatePostData]
        public ViewFilterObject Filter {
            get { return _Filter; }
            set {
                _Filter = value;
                OnChanged("Criteria");
            }
        }
        [CriteriaOptions("ObjectType")]
        [ImmediatePostData]
        public string Criteria {
            get { return Filter != null ? Filter.Criteria : String.Empty; }
            set {
                if (Filter != null) {
                    Filter.Criteria = value;
                }
            }
        }
        private Type _ObjectType;
        [Browsable(false)]
        public Type ObjectType {
            get { return _ObjectType; }
            set { _ObjectType = value; }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        
        protected void OnChanged([CallerMemberName] string memberName = "") {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(memberName));
        }
    }
}
