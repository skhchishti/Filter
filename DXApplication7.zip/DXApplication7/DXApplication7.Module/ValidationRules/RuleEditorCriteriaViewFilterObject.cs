﻿using DevExpress.Persistent.Validation;
using E1554.Module;

namespace DXApplication7.Module.ValidationRules {
    [CodeRule]
    public class RuleEditorCriteriaViewFilterObject : RuleEditorCriteriaBase {
        public RuleEditorCriteriaViewFilterObject() : base(nameof(RuleEditorCriteriaViewFilterObject), "Save", typeof(ViewFilterObject)) { }
        public RuleEditorCriteriaViewFilterObject(IRuleBaseProperties properties) : base(properties) { }
        protected override string TargetPropertyName => nameof(ViewFilterObject.Criteria);
    }
}
