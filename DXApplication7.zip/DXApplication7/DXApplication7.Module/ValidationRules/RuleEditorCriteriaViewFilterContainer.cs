﻿using DevExpress.Persistent.Validation;
using E1554.Module;

namespace DXApplication7.Module.ValidationRules {
    [CodeRule]
    public class RuleEditorCriteriaViewFilterContainer : RuleEditorCriteriaBase {
        public RuleEditorCriteriaViewFilterContainer() : base(nameof(RuleEditorCriteriaViewFilterContainer), "Save", typeof(ViewFilterContainer)) { }
        public RuleEditorCriteriaViewFilterContainer(IRuleBaseProperties properties) : base(properties) { }
        protected override string TargetPropertyName => nameof(ViewFilterContainer.Criteria);
    }
}
