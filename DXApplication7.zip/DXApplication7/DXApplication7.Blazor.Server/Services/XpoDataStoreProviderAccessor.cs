﻿using System;
using DevExpress.ExpressApp.Xpo;

namespace DXApplication7.Blazor.Server.Services {
    public class XpoDataStoreProviderAccessor {
        public IXpoDataStoreProvider DataStoreProvider { get; set; }
    }
}
